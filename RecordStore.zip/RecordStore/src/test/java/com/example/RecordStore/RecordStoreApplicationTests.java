package com.example.RecordStore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecordStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
